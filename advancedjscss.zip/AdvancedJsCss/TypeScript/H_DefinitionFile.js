/// <reference path="jQuery.d.ts" />
// Řádkem výše, se přibalí definiční soubor pro jQuery.
// Nyní můžete psát jQuery kód v TypeScriptu
$(function () {
    $('body')
        .append($('<h1>').text('It works!'));
});
//# sourceMappingURL=H_DefinitionFile.js.map