﻿

// https://github.com/borisyankov/DefinitelyTyped
// Web Essentials 2.9 (ve VS2015 Web Compiler https://visualstudiogallery.msdn.microsoft.com/3b329021-cd7a-4a01-86fc-714c2d05bb6c )
// Nastavení web essentials
// UTF-8

// Ukázky:
// http://www.typescriptlang.org/Playground/

